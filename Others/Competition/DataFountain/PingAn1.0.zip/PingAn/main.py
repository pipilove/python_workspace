# -*- coding:utf8 -*-
import csv
import os
import sys
import pandas as pd

FILE_FOLDER = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(os.path.join(FILE_FOLDER, 'packages'))

try:
    from packages.DriveRiskPredict import DriveRiskEstimator
    from packages.DataPreprocess import readCsv
    from packages.Parameters import *
    from packages.ModelEvaluation import modelEvaluation
except:
    from .packages.DriveRiskPredict import DriveRiskEstimator
    from .packages.DataPreprocess import readCsv
    from .packages.Parameters import *
    from .packages.ModelEvaluation import modelEvaluation


def process0():
    """
    处理过程，在示例中，使用随机方法生成结果，并将结果文件存储到预测结果路径下。
    :return:
    """
    import numpy as np

    with open(path_test) as lines:
        with(open(os.path.join(path_test_out, "test.csv"), mode="w")) as outer:
            writer = csv.writer(outer)
            i = 0
            ret_set = set([])
            for line in lines:
                if i == 0:
                    i += 1
                    writer.writerow(["Id", "Pred"])  # 只有两列，一列Id为用户Id，一列Pred为预测结果(请注意大小写)。
                    continue
                item = line.split(",")
                if item[0] in ret_set:
                    continue
                # 此处使用随机值模拟程序预测结果
                writer.writerow([item[0], np.random.rand()])  # 随机值

                ret_set.add(item[0])  # 根据赛题要求，ID必须唯一。输出预测值时请注意去重


def process():
    # data_preprocess()
    data_df = readCsv(path_train)
    x, y = data_df.ix[:, 0:-1], data_df.ix[:, -1]

    '''模型交叉验证'''
    # modelEvaluation(x, y)

    '''模型训练'''
    estimator = DriveRiskEstimator().fit(x, y)

    '''模型测试'''
    test_data = pd.read_csv(path_test)
    print(test_data.head())

    test_pred = estimator.predict(new_samples=test_data)
    test_data_pred_df = pd.DataFrame(test_data['TERMINALNO'], copy=True)
    test_data_pred_df.columns = ['Id']
    test_data_pred_df['Pred'] = test_pred
    test_data_pred_df = test_data_pred_df.drop_duplicates(subset=['Id'])

    print(test_data_pred_df.head())
    test_data_pred_df.to_csv(os.path.join(path_test_out, 'test.csv'), index=None)


if __name__ == "__main__":
    print("****************** start **********************")
    # 程序入口
    process()
