#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
__title__ = '参数设置'
__author__ = 'pipi'
__mtime__ = '5/7/18'
__email__ = 'pipijob@126.com'
"""

path_train = "/data/dm/train.csv"  # 训练文件
path_train1 = "data/dm/train1.csv"  # 预处理后的训练文件
path_test = "/data/dm/test.csv"  # 测试文件

path_test_out = "model/"  # 预测结果输出路径为model/xx.csv,有且只能有一个文件并且是CSV格式。

cv = 3  # cv折交叉验证
