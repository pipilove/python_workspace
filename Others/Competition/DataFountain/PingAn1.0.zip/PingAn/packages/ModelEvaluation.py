#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
__title__ = '模型评估'
__author__ = 'pipi'
__mtime__ = '5/2/18'
__email__ = 'pipijob@126.com'
"""
from sklearn.model_selection import cross_val_score

try:
    from DriveRiskPredict import DriveRiskEstimator
    from Parameters import cv
except:
    from .DriveRiskPredict import DriveRiskEstimator
    from .Parameters import cv


def modelEvaluation(x, y, cv=cv):
    estimator = DriveRiskEstimator().fit(x, y)
    scores = cross_val_score(estimator, x, y, cv=cv)
    print('{}折交叉验证scores：\n{}'.format(cv, scores))
    print(sum(scores) / cv)
