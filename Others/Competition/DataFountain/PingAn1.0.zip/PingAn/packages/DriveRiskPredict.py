#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
__title__ = '驾驶风险预测模型'
__author__ = 'pipi'
__mtime__ = '4/28/18'
__email__ = 'pipijob@126.com'
"""
from sklearn.base import BaseEstimator
from sklearn import metrics
import numpy as np
import math


def giniCoefficient(x, y):
    '''
    gini系数计算
    :param x: 推测值（保费，人口）
    :param y: 实际值（赔款，财富）
    :return:
    '''
    x = np.asarray(x)
    y = np.asarray(y)
    x.__add__(0)
    y.__add__(0)

    x = np.cumsum(x)
    if x[-1] != 0:
        x = x / x[-1]

    y = np.cumsum(y)
    if y[-1] != 0:
        y = y / y[-1]

    area = metrics.auc(x, y, reorder=True)
    gini_cof = 1 - 2 * area

    return gini_cof if math.fabs(gini_cof) > pow(math.e, -6) else 0


class DriveRiskEstimator(BaseEstimator):
    def __init__(self):
        pass

    def get_params(self, deep=True):
        return {}

    def set_params(self, **params):
        return self

    # todo
    def fit(self, x, y):
        '''
        模型训练
        :param x:
        :param y:
        :return:
        '''
        return self

    # todo
    def predict(self, new_samples):
        '''
        模型预测
        :param new_samples:
        :return:
        '''
        values = [0, 0.475132, 0.051675, 1.301619, 0.845866, 0.069589, 2.36856, 0.504856, 0.660832, 0.489912, 1.454962,
                  0.40478, 20.742695, 1.686593, ]
        probs = [0.876937062, 0.014183476, 0.01331775, 0.011975875, 0.011283294, 0.010605142, 0.010071278, 0.008960263,
                 0.008541829, 0.008224396, 0.008123395, 0.006709376, 0.006146654, 0.004920209, ]
        result = np.random.choice(values, size=len(new_samples), p=probs)
        # result = np.zeros(len(new_samples))
        return result

    def score(self, x, y_true):
        self.y_true = y_true
        y_pred = self.predict(x)
        score = giniCoefficient(y_pred, y_true)
        return score
