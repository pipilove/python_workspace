#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
__title__ = '数据分析及处理'
__author__ = 'pipi'
__mtime__ = '4/27/18'
__email__ = 'pipijob@126.com'
"""
import pandas as pd
from sklearn import model_selection

try:
    from Parameters import *
except:
    from .Parameters import *


def readCsv(path):
    """
    :return:
    """
    data_df = pd.read_csv(path)
    data_df.columns = ["TERMINALNO", "TIME", "TRIP_I   D", "LONGITUDE", "LATITUDE", "DIRECTION", "HEIGHT", "SPEED",
                       "CALLSTATE", "Y"]
    return data_df


def dataAnalysis(path):
    data = readCsv(path)
    print(data.head())
    print('{:*^60}'.format(' TERMINALNO describe '))
    print(data['TERMINALNO'].astype('category').describe())
    print('{:*^60}'.format(' 每个TERMINALNO 数据记录数 '))
    print(data.groupby('TERMINALNO').count().ix[:, 0].tail(14))
    print('{:*^60}'.format(' label的总数及不同label各自的数目 '))
    # print(data['Y'].describe())
    print(data['Y'].count())
    print(data['Y'].value_counts())
    print('*' * 50)


def dataPreprocess():
    """划分出部分伪测试数据"""
    data_df = readCsv(path_train)
    train_data_df, test_data_df = model_selection.train_test_split(data_df, test_size=0.01)
    test_data_df.ix[:, 0:-1].to_csv(path_test, index=False)


if __name__ == '__main__':
    print('\033[31m{:*^60}\033[0m'.format('数据分析'))
    dataAnalysis(path_train)
    # print('\033[31m{:*^60}\033[0m'.format('数据划分'))
    # dataPreprocess()
    print('*' * 60)
